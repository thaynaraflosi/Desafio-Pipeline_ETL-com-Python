# swagger_client.DeviceApi

All URIs are relative to *https://virtserver.swaggerhub.com/THAYNARAFLOSI_1/FCR/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**get_devices**](DeviceApi.md#get_devices) | **GET** /users/ | 
[**get_switch_state**](DeviceApi.md#get_switch_state) | **POST** /lighting/switches/{deviceId} | 
[**register**](DeviceApi.md#register) | **PUT** /users/ | 
[**set_dimmer**](DeviceApi.md#set_dimmer) | **DELETE** /lighting/dimmers/{deviceId}/{value} | 
[**set_dimmer_timer**](DeviceApi.md#set_dimmer_timer) | **GET** /lighting/dimmers/{deviceId}/{value}/timer/{timeunit} | 

# **get_devices**
> list[str] get_devices(id)



returns all ID registered devices

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DeviceApi()
id = 56 # int | 

try:
    api_response = api_instance.get_devices(id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DeviceApi->get_devices: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **int**|  | 

### Return type

**list[str]**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json, apllication/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **get_switch_state**
> DeviceState get_switch_state(device_id)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DeviceApi()
device_id = 'device_id_example' # str | 

try:
    api_response = api_instance.get_switch_state(device_id)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DeviceApi->get_switch_state: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **device_id** | **str**|  | 

### Return type

[**DeviceState**](DeviceState.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **register**
> register(body=body)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DeviceApi()
body = swagger_client.DeviceRegistrationInfo() # DeviceRegistrationInfo |  (optional)

try:
    api_instance.register(body=body)
except ApiException as e:
    print("Exception when calling DeviceApi->register: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**DeviceRegistrationInfo**](DeviceRegistrationInfo.md)|  | [optional] 

### Return type

void (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **set_dimmer**
> ApiResponse set_dimmer(device_id, value)



### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DeviceApi()
device_id = 'device_id_example' # str | 
value = 56 # int | 

try:
    api_response = api_instance.set_dimmer(device_id, value)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DeviceApi->set_dimmer: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **device_id** | **str**|  | 
 **value** | **int**|  | 

### Return type

[**ApiResponse**](ApiResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **set_dimmer_timer**
> ApiResponse set_dimmer_timer(device_id, value, timeunit, units=units)



sets a dimmer to a specific value on a timer

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DeviceApi()
device_id = 'device_id_example' # str | 
value = 56 # int | 
timeunit = 56 # int | 
units = 'milliseconds' # str |  (optional) (default to milliseconds)

try:
    api_response = api_instance.set_dimmer_timer(device_id, value, timeunit, units=units)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DeviceApi->set_dimmer_timer: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **device_id** | **str**|  | 
 **value** | **int**|  | 
 **timeunit** | **int**|  | 
 **units** | **str**|  | [optional] [default to milliseconds]

### Return type

[**ApiResponse**](ApiResponse.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

