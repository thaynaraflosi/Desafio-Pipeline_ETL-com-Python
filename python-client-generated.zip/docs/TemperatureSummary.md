# TemperatureSummary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**zones** | [**list[TemperatureZone]**](TemperatureZone.md) |  | [optional] 
**zone_status** | [**list[TemperatueZoneStatus]**](TemperatueZoneStatus.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

