# ForecastTemperature

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**low** | **float** |  | [optional] 
**high** | **float** |  | [optional] 
**morning** | **float** |  | [optional] 
**day** | **float** |  | [optional] 
**evening** | **float** |  | [optional] 
**night** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

